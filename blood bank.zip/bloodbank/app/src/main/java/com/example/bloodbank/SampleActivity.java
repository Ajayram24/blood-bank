package com.example.bloodbank;

import android.app.Activity;

public class SampleActivity extends Activity {
}
